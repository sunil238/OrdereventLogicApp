﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net;
using System.Text.RegularExpressions;
using System.Net.Http;
using Newtonsoft.Json.Linq;

namespace CurrencyConvert
{
    public static class CurrencyConvert
    {
        [FunctionName("CurrencyConvert")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string name = req.Query["name"];

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            name = name ?? data?.name;

            string responseMessage = string.IsNullOrEmpty(name)
                ? "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response."
                : $"Hello, {name}. This HTTP triggered function executed successfully.";

            string baseCurrency = req.Query["base"];
            if (baseCurrency == null)
            {
                baseCurrency = "EUR";
            }
            string requiredCurrency = req.Query["required"];
            if (requiredCurrency == null)
            {
                requiredCurrency = "USD";
            }
            double price = Convert.ToDouble(req.Query["price"]);
            double rate = Convert.ToDouble(req.Query["rate"]);
            double finalRate=0;
            if (rate==0)
            {
                rate = 1;
            }
            string apiKey = "1a0fa5493f455e4b6ca1f66a087e7028";
            string currencyQuery = String.Format("http://api.exchangeratesapi.io/latest?symbols={0}&base={1}&access_key={2}", requiredCurrency, baseCurrency, apiKey);
            using (var client = new HttpClient())
            {
                     HttpResponseMessage respons = client.GetAsync(currencyQuery).Result;
                    if (respons.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Request Message Information:- \n\n" + respons.RequestMessage + "\n");
                        Console.WriteLine("Response Message Header \n\n" + respons.Content.Headers + "\n");
                        // Get the response
                        var customerJsonString = await respons.Content.ReadAsStringAsync();
                       // dynamic jsonStr = JsonConvert.DeserializeObject(customerJsonString);
                        finalRate = Convert.ToDouble(JObject.Parse(customerJsonString)["rates"]["USD"]);
                    }
            }
            var convertedPrice = price * finalRate * rate;
            return new OkObjectResult(convertedPrice);
        }
    }
}
